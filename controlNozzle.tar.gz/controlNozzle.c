#include <mosquitto.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

#define MQTT_SERVER "localhost"
#define MQTT_PORT 1883
#define MQTT_USERNAME "sunless"
#define MQTT_PASSWORD "BDf@v3JsryLn25YX"

#define I2C_CPLD	0x13
#define I2C_POT     0x2e
#define I2C_ADC     0x4d

#define DEFAULT_VOLTAGE 0x0F
#define DEFAULT_PWM 0x5A

static gboolean useMQTT = FALSE;
static gboolean verbose = FALSE;
static GError *err = NULL;
static int fd;
static uint16_t adcValue;
static float adcVoltage;
static uint8_t currentVoltage;
static uint8_t currentPWM;
static int defaultVoltage =  DEFAULT_VOLTAGE;
static int defaultPwm = DEFAULT_PWM;
static struct mosquitto *mosq;

uint8_t flag_pwm_active = 0;
uint8_t flag_switcher_active = 0;
uint32_t i2c_packet_delay = 100000;

static GOptionEntry entries[] =
{
	{ "verbose", 'v', 0, G_OPTION_ARG_NONE, &verbose, "Be verbose (skips pin probing results)" , NULL },
	{ "useMQTT", 'm', 0, G_OPTION_ARG_NONE, &useMQTT, "Send results over MQTT", NULL },
	{ "voltage", 't', 0, G_OPTION_ARG_INT, &defaultVoltage, "Set default voltage", NULL },
	{ "pwm", 'p', 0, G_OPTION_ARG_INT, &defaultPwm, "Set default pwm", NULL },
	{ NULL }
};

volatile sig_atomic_t exitFlag = 0;
void sigintHandler(int) {
	exitFlag = 1;
}

void mqttConnect(struct mosquitto *mosq, void *obj, int reasonCode)
{
	int rc;

	if (reasonCode != 0)
	{
		g_warning("controlNozzle: Couldn't connect to MQTT broker: %s", mosquitto_connack_string(reasonCode));
		mosquitto_disconnect(mosq);
	}
	/*
	 * Subscribe to topics we are interested in.
	 */
	rc = mosquitto_subscribe(mosq, NULL, "sunless/update_nozzle_voltage", 1);
	if (rc != MOSQ_ERR_SUCCESS)
	{
		g_warning("controlNozzle: Couldn't subscribe to 'update_nozzle_voltage' topic: %s", mosquitto_strerror(rc));
		mosquitto_disconnect(mosq);
	}
	rc = mosquitto_subscribe(mosq, NULL, "sunless/update_nozzle_pwm", 1);
	if (rc != MOSQ_ERR_SUCCESS)
	{
		g_warning("controlNozzle: Couldn't subscribe to 'update_nozzle_pwm' topic: %s", mosquitto_strerror(rc));
		mosquitto_disconnect(mosq);
	}
}

void mqttSubscribe(struct mosquitto *mosq, void *obj, int mid, int qosCount, const int *grantedQos)
{
	int i;

	g_debug("controlNozzle: Subscribed (mid: %d): %d", mid, grantedQos[0]);
	for (i = 1; i < qosCount; i++)
	{
		g_debug("controlNozzle: %d:granted qos = %d\n", i, grantedQos[i]);
	}
}

void mqttMessage(struct mosquitto *mosq, void *obj, const struct mosquitto_message *message)
{
	struct i2c_rdwr_ioctl_data desc;
	struct i2c_msg msg;
	unsigned char data[2];
	uint8_t number;

	g_debug("controlNozzle: Received MQTT message: %s %d %s", message->topic, message->qos, (char *)message->payload);

	if (!g_strcmp0(message->topic, "sunless/update_nozzle_voltage"))
	{
		number = (uint8_t)strtol((char *)message->payload, NULL, 16);
		msg.addr = I2C_POT;
		msg.flags = 0;
		msg.len = 2;
		data[0] = 0x00;
		data[1] = number;
		msg.buf = data;

		desc.msgs = &msg;
		desc.nmsgs = 1;
		usleep(i2c_packet_delay);
		if (ioctl(fd, I2C_RDWR, &desc) <= 0)
		{
			g_message("Failed to write voltage");
		}
		currentVoltage = number;
	}
	if (!g_strcmp0(message->topic, "sunless/update_nozzle_pwm"))
	{
		number = (uint8_t)strtol((char *)message->payload, NULL, 16);
		msg.addr = I2C_CPLD;
		msg.flags = 0;
		msg.len = 2;
		data[0] = 0x02;
		data[1] = number;
		msg.buf = data;

		desc.msgs = &msg;
		desc.nmsgs = 1;
		usleep(i2c_packet_delay);
		if (ioctl(fd, I2C_RDWR, &desc) <= 0)
		{
			g_message("Failed to write PWM");
		}
		currentPWM = number;
	}
}

static gboolean published = false;
void mqttPublish(struct mosquitto *mosq, void *obj, int mid)
{
	published = true;
	g_debug("controlNozzle: Message with mid %d has been published.", mid);
}

int mqPublish(const gchar *topic, const gchar *payload) {
	int rc;
	int mid = 0;
	int len = payload == NULL ? 0 : strlen(payload);
	published = false;
	rc = mosquitto_publish(mosq, &mid, topic, len, payload, 2, false);
	g_debug("publishing to topic '%s' mid(%d) rc(%d) payload:'%s'", topic, mid, rc, payload);
	if (rc != MOSQ_ERR_SUCCESS) {
		g_warning("controlNozzle: Couldn't publish MQTT message: %s", mosquitto_strerror(rc));
	}
	// HACK: wait for publish before exiting program due to mosquitto loop running in another thread, otherwise errors won't get published
	while (!published) {
		usleep(100);
	}
	return rc;
}

void publishError(int errCode, const gchar *errMessage) {
	if (!useMQTT) {
		return;
	}
	gchar *payload;
	payload = g_strdup_printf("{ \"code\":%d, \"message\": \"%s\" }", errCode, errMessage);
	mqPublish("sunless/error", payload);
	g_free(payload);
}

int main(int argc, char **argv)
{
	GOptionContext *context = NULL;
	struct i2c_rdwr_ioctl_data desc;
	struct i2c_msg msg;
	unsigned char data[2];
	gchar *statusMessage = NULL;
	int rc;

	signal(SIGINT, sigintHandler);
	signal(SIGTERM, sigintHandler);
	context = g_option_context_new("- Spray Nozzle Control For Sunless");
	g_option_context_add_main_entries(context, entries, NULL);
    if (!g_option_context_parse (context, &argc, &argv, &err))
    {
        g_print("controlNozzle: option parsing failed: %s\n", err->message);
        g_free(context);
        g_free(err);
        exit(EXIT_FAILURE);
    }

	if (defaultVoltage < 0 || defaultVoltage > 255) {
		defaultVoltage = DEFAULT_VOLTAGE;
	}
	if (defaultPwm < 0 || defaultPwm > 255) {
		defaultPwm = DEFAULT_PWM;
	}
	defaultPwm = defaultPwm & 0xFF;
	defaultVoltage = defaultVoltage & 0xFF;
	g_message("defaulPwm: 0x%x defaultVoltage: 0x%x", defaultPwm, defaultVoltage);
	if (useMQTT)
	{
		mosq = mosquitto_new(NULL, true, NULL);
		if (mosq == NULL)
		{
			g_message("controlNozzle: Unable to create mqtt instance");
			mosquitto_lib_cleanup();
			return(EXIT_FAILURE);
		}
		mosquitto_connect_callback_set(mosq, mqttConnect);
		mosquitto_subscribe_callback_set(mosq, mqttSubscribe);
		mosquitto_message_callback_set(mosq, mqttMessage);
		mosquitto_publish_callback_set(mosq, mqttPublish);

		if (mosquitto_username_pw_set(mosq, MQTT_USERNAME, MQTT_PASSWORD) != MOSQ_ERR_SUCCESS)
		{
			g_message("controlNozzle: Unable to set mqtt username/password");
			mosquitto_destroy(mosq);
			mosquitto_lib_cleanup();
			return(EXIT_FAILURE);
		}
		if (mosquitto_connect(mosq, MQTT_SERVER, MQTT_PORT, 60) != MOSQ_ERR_SUCCESS)
		{
			g_message("controlNozzle: Unable to connect to MQTT server");
			mosquitto_destroy(mosq);
			mosquitto_lib_cleanup();
			return(EXIT_FAILURE);
		}
		if (mosquitto_loop_start(mosq) != MOSQ_ERR_SUCCESS)
		{
			g_message("controlNozzle: Unable to connect to start MQTT thread");
			mosquitto_destroy(mosq);
			mosquitto_lib_cleanup();
			return(EXIT_FAILURE);
		}
	}
	if ((fd = open("/dev/sunless/i2c", O_RDWR)) < 0)
	{
		g_message("controlNozzle: Unable to open i2c bus.");
		publishError(7160, "controlNozzle: Unable to open i2c bus.");
		return(EXIT_FAILURE);
	}

	// Set default voltage
	msg.addr = I2C_POT;
	msg.flags = 0;
	msg.len = 2;
	data[0] = 0x00;
	data[1] = (defaultVoltage & 0xFF);
	msg.buf = data;

	desc.msgs = &msg;
	desc.nmsgs = 1;
    usleep(i2c_packet_delay);
	if (ioctl(fd, I2C_RDWR, &desc) <= 0)
	{
		g_message("Failed to write voltage");
		publishError(7160, "controlNozzle: Failed to write voltage.");
		return(EXIT_FAILURE);
	}
	currentVoltage = defaultVoltage;

	// Set default PWM
	msg.addr = I2C_CPLD;
	msg.flags = 0;
	msg.len = 2;
	data[0] = 0x02;
	data[1] = (defaultPwm & 0xFF);
	msg.buf = data;

	desc.msgs = &msg;
	desc.nmsgs = 1;
    usleep(i2c_packet_delay);
	if (ioctl(fd, I2C_RDWR, &desc) <= 0)
	{
		g_message("Failed to write PWM");
		publishError(7160, "controlNozzle: Failed to write PWM.");
		return(EXIT_FAILURE);
	}
	currentPWM = defaultPwm;

	// Turn on PWM
	msg.addr = I2C_CPLD;
	msg.flags = 0;
	msg.len = 2;
	data[0] = 0x01;
	data[1] = 0x01;
	msg.buf = data;

	desc.msgs = &msg;
	desc.nmsgs = 1;
    usleep(i2c_packet_delay);
	if (ioctl(fd, I2C_RDWR, &desc) <= 0)
	{
		g_message("Failed to start PWM");
		publishError(7160, "controlNozzle: Failed to start PWM.");
		return(EXIT_FAILURE);
	}
	flag_pwm_active = 1;

	// Turn on switcher
	msg.addr = I2C_CPLD;
	msg.flags = 0;
	msg.len = 2;
	data[0] = 0x00;
	data[1] = 0x01;
	msg.buf = data;

	desc.msgs = &msg;
	desc.nmsgs = 1;
    usleep(i2c_packet_delay);
	if (ioctl(fd, I2C_RDWR, &desc) <= 0)
	{
		g_message("Failed to start switcher");
		publishError(7160, "controlNozzle: Failed to start switcher.");
		return(EXIT_FAILURE);
	}
	flag_switcher_active = 1;

	while (!exitFlag)
	{
		// TODO: send adc over mqtt
		usleep(250 * 1000UL);

		msg.addr = I2C_ADC;
		msg.flags = I2C_M_RD;
		msg.len = 2;
		msg.buf = data;

		if (ioctl(fd, I2C_RDWR, &desc) <=0)
		{
			g_message("Failed to read ADC from nozzle");
			exitFlag = 1;
		}
		adcValue = (data[0] << 8) | data[1];
		adcVoltage = adcValue * 0.4098;
		if (useMQTT)
		{
			statusMessage = g_strdup_printf("{ \"POTVoltage\": \"0x%02X\", \"PWMValue\": \"0x%02X\", \"ADCValue\": %d, \"ADCVoltage\": %f }", currentVoltage, currentPWM, adcValue, adcVoltage);
			rc = mosquitto_publish(mosq, NULL, "sunless/nozzleInfo", strlen(statusMessage),
                statusMessage, 2, false);
			if (rc != MOSQ_ERR_SUCCESS)
				g_warning("controlNozzle: Couldn't publish MQTT message: %s", mosquitto_strerror(rc));
			g_free(statusMessage);
			if (verbose)
				g_message("POT Voltage: 0x%02x, PWM Value: 0x%02X, ADC Value: %d, Calculated Voltage: %f", currentVoltage, currentPWM, adcValue, adcVoltage);
		}
		else
		{
			g_message("POT Voltage: 0x%02x, PWM Value: 0x%02X, ADC Value: %d, Calculated Voltage: %f", currentVoltage, currentPWM, adcValue, adcVoltage);
		}
	}

	// Turn off switcher
	while(flag_switcher_active){
		msg.addr = I2C_CPLD;
		msg.flags = 0;
		msg.len = 2;
		data[0] = 0x00;
		data[1] = 0x00;
		msg.buf = data;

		desc.msgs = &msg;
		desc.nmsgs = 1;
		usleep(i2c_packet_delay);
		if (ioctl(fd, I2C_RDWR, &desc) <= 0)
		{
			g_message("Failed to stop switcher");
			//return(EXIT_FAILURE);
		}else{
			flag_switcher_active = 0;
			g_message("Switcher stopped");
		}
	}

	// Turn off PWM
	while(flag_pwm_active){
		msg.addr = I2C_CPLD;
		msg.flags = 0;
		msg.len = 2;
		data[0] = 0x01;
		data[1] = 0x00;
		msg.buf = data;

		desc.msgs = &msg;
		desc.nmsgs = 1;
		usleep(i2c_packet_delay);
		if (ioctl(fd, I2C_RDWR, &desc) <= 0)
		{
			g_message("Failed to stop PWM");
			//return(EXIT_FAILURE);
		}else{
			flag_pwm_active = 0;
			g_message("PWM Stopped");
		}
	}
	close(fd);
	if (useMQTT)
	{
		mosquitto_disconnect(mosq);
		mosquitto_lib_cleanup();
	}
	return(EXIT_SUCCESS);
}
